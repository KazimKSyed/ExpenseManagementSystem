var express=require('express');
var router=express.Router();
var category=require('../controller/categoryController');
router.get('/categories',category.getCategories);
router.post('/addCategory',category.addCategories);
router.put('/updateCategory/:categoryId',category.updateCategory);
router.delete('/deleteCategory/:categoryId',category.deleteCategory);


module.exports=router;