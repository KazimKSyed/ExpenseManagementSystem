const mongoose=require('mongoose')
var bcrypt=require('bcryptjs')
const userSchema=mongoose.Schema({
    id:{
        type:String,
        required:"unique id required",
        unique:true
    },
    name:{
        type:String,
        required:true
    },
    phone:{
        type:String,
        required:true
    },
    email:{
        type:String,
        unique:true,
       required:"email required",
    },
    logInName:{
        type:String,
       required:"logInName required",
    },
    password:{
        type:String,
        required:"password required",
       minlength:[4,'Password must be atl;east 4 charector']
    },
    role:{
        type:String,
        required:true,
     
   
    },
    status:{
        type:String,
       required:true,
    },
});



const user=mongoose.model('user',userSchema);
module.exports=user;