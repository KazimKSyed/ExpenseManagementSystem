var user=require('../model/user')


exports.getUsers=(req,res,next)=>{
    user.find(function(err,user){

        if(err)
        res.json(err);
        else
        res.json(user);
    })
};
exports.registerUser=(req,res,next)=>{
    let newUser=new user({
        id:req.body.id,
        name:req.body.name,
        phone:req.body.phone,
        email:req.body.email,
        logInName:req.body.logInName,
        password:req.body.password,
        role:req.body.role,
        status:req.body.status
       
      

    });
    newUser.save((err,item)=>{
        if(err){
            res.json(err)
        }else{
            res.json({msg:"user registerd Succesfully"});
        }
    })
};
exports.logIn=(req,res,next)=>{
   user.findOne({"logInName":req.body.logInName,"password":req.body.password},function(err,result){
       if(err){
           res.json(err)
       }else{
        console.log(result);
           res.json({msg:"user logged in Succesfully"})
          
       }
   })
};
